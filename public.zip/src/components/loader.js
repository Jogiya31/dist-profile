import React from "react";

const Loader = () => {
  return (
    <>
      <div class="loader mt-1"></div>
      <div class="loader mt-1"></div>
      <div class="loader mt-1"></div>
    </>
  );
};

export default Loader;
